# Original Ridge Model Export

This model was fitted and registered locally as `bike_demand_forecast`, version 1. Its original source run ID is `d6fc343b23934fba8bfb053c5413f4e8`.

The folder includes the fitted model in skops format, the MLflow model descriptor, dependency metadata, example inputs, data snapshots, and the final offline assessment. Remote uploading or registration will produce separate remote identities.

Load the model with `mlflow.sklearn.load_model("model_export")` in the recorded dependency environment. The original test snapshot includes `ridge_pred` for checking prediction consistency. The target and baseline columns are evaluation evidence, not model inputs.
